package ActualStuff;
import java.io.IOException;

public class PatientManagerTest {
	public static void main(String[] args) throws IOException {
		Patient_Manager.addPatient("John");
		Patient_Manager.setStatus("John", "L");
		Patient_Manager.addPatient("Sally");
	}
}