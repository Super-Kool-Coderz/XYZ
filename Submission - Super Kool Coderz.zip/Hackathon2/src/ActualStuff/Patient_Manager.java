package ActualStuff;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;

public class Patient_Manager {
	static ArrayList<Patient> patients = new ArrayList<Patient>();
	static final String WAITING = "Waiting";
	static final String READY = "Ready";
	static final String INPROGRESS = "In-Progress";
	static final String ONHOLD = "On Hold";
	static final String CHECKEDOUT = "Checked Out";
	static final Comparator<Patient> COMPNAME = new PatientNameComparator();
	static final Comparator<Patient> COMPRANK = new PatientRankComparator();
	static private Scanner input = new Scanner(System.in);
	
	public Patient_Manager() {		
	}
	
	public static void main(String[] args) throws IOException {
		Patient_Manager manager = new Patient_Manager();
		
		String a = "";
		while(!a.equalsIgnoreCase("Exit")) {
			System.out.println("Choose one of the options below:\n(Submit Patient, Edit Current Patient, View Patients, Next Patient):\n");
			a = input.nextLine();
			switch (a.substring(0,2).toLowerCase()) {
			case "su":
				manager.createNewPatient();
				break;
			case "ed":
				manager.editCurrentPatient();
				break;
			case "vi":			
				manager.viewPatients();
				break;
			case "ne":
				Patient nextP = patients.get(0);
				System.out.println(nextP.toString());
				break;
				
			default:
				if (!a.equalsIgnoreCase("Exit")) System.out.println("Invalid input, try again.");
			}
		}


		input.close();
	}
	
	private void createNewPatient() throws IOException {
		Patient newPatient = createAccount();
		addPatient(newPatient);
	}
	
	private void editCurrentPatient() throws IOException {
		String a = "";
		
		System.out.println("\n\nEditing...");
		
		while (!a.equalsIgnoreCase("Exit")) {
			System.out.println("Enter name of patient to edit or type \"view patients\"");
			a = input.nextLine();
			switch (a.toLowerCase()) {
			case "view patients":
				listPatientNames(COMPRANK);
				break;
			default:
				if (patients.contains(new Patient(a))) {
					editPatient(a);
				}else {
					System.out.printf("\n\nUnable to find patient %s\n",a);
				}
			}
		}
	}

	private void editPatient(String a) throws IOException {
		Patient pat = getPatient(a);
		System.out.println(pat);
		String b = "";
		while (!b.equalsIgnoreCase("Exit")) {
			System.out.println("Change what about the patient?\n(Name, Age, Condition, Severity, Status, Room number)");
			b = input.nextLine();
			switch (b.toLowerCase()) {
			case "name":
				System.out.print("Enter a new name for patient:");
				pat.setName(input.nextLine());
				break;
			case "age":
				System.out.print("Enter a new age (integer) for patient:");
				pat.setAge(Integer.parseInt(input.nextLine()));
				break;
			case "condition":
				System.out.print("Explain condition of patient:");
				pat.setCondition(input.nextLine());
				break;
			case "severity":
				System.out.print("Enter a severity level (1-10) for patient:");
				pat.setRank(Integer.parseInt(input.nextLine()));
				break;
			case "status":
				System.out.print("Enter patient status\n((1)WAITING,(2)READY,(3)INPROGRESS,(4)ONHOLD,(5)CHECKEDOUT):");
				b = input.nextLine();
				switch (b.toLowerCase()) {
				case "1":
				case "waiting":
					pat.setStatus(WAITING);
					break;
				case "2":
				case "ready":
					pat.setStatus(READY);
					break;
				case "3":
				case "inprogress":
				case "in-progress":
				case "in progress":
					pat.setStatus(INPROGRESS);
					break;
				case "4":
				case "onhold":
				case "on hold":
				case "on-hold":
					pat.setStatus(ONHOLD);
					break;
				case "5":
				case "checkedout":
				case "checked-out":
				case "checked out":
					pat.setStatus(CHECKEDOUT);
					break;
				}
				break;
			case "room number":
				System.out.print("Enter a room number for the patient");
				pat.setRoomNum(Integer.parseInt(input.nextLine()));
				break;
			default:
				if (!a.equalsIgnoreCase("Exit")) System.out.println("Invalid input, try again.");	
			}
		}
	}
	
	private void viewPatients() {
		String a = "";

		while (!a.equalsIgnoreCase("exit")) {
			System.out.println("View patients by (1)Name, (2)Rank, (3)Condition");
			a = input.nextLine();
			switch (a.toLowerCase()) {
			case "1":
			case "name":
				listPatientNames(COMPNAME);
				break;
			case "2":
			case "rank":				
				listPatientNames(COMPRANK);
				break;
			case "3":
			case "condition":
				patientStatusMenu();
				break;
			default:
				System.out.print("\nInvalid input, try again.");
			}
			
		}
	}
	
	private void listPatientNames(Comparator<Patient> a) {
		ArrayList<Patient> unsortedPatients = new ArrayList<Patient>(patients);
		unsortedPatients.sort(a);
		for(Patient p : patients) {
			System.out.println(p.getName());
		}
	}
	
	private void patientStatusMenu() {
		String a = "";
		
		while(!a.equalsIgnoreCase("Exit")){
			System.out.print("Enter a patient status to view (Waiting,Ready,In-Progress,On Hold,Checked Out):");
			a = input.nextLine();
			ArrayList<Patient> c = getListStatus(a);
			c.sort(COMPRANK);
			for(Patient p : c) {
				System.out.println(p.toString()+ "\n");
			}
		}
	}
	
	public ArrayList<Patient> getList(){
		return patients;
	}
	
	public static void addPatient(Patient p) throws IOException {
		if (patients.contains(p)) {
			p.setStatus(WAITING);
			createAccountFile(p);
		}
		else {
			patients.add(p);
			patients.sort(new PatientRankComparator());
		}
	}
	
	public static Patient getPatient(String name) throws IOException {
		for (Patient p : patients) {
			if (p.getName().equalsIgnoreCase(name)) {
				return p;
			}
		}
		return null;
	}
	
	public static void setRank(String name, int rank) throws IOException {
		getPatient(name).setRank(rank);
	}
	
	public static void setStatus(String name, String status) throws IOException {
		getPatient(name).setStatus(status);
		createAccountFile(getPatient(name));
		if (status == CHECKEDOUT) {
			patients.remove(getPatient(name));
		}
	}
	
	public void setAge (String name, int age) throws IOException {
		getPatient(name).setAge(age);
	}
	
	//Patients are sorted by Rank
	public void sortListRank() {
		patients.sort(COMPNAME);
	}
	
	//Patients sorted by Name
	public void sortListName() {
		patients.sort(COMPRANK);
	}
	
	public static void setRoomNum(String name, int roomNum) throws IOException {
		getPatient(name).setRoomNum(roomNum);
	}
	
	public ArrayList<Patient> getListStatus(String status){
		ArrayList<Patient> list = new ArrayList<Patient>();
		for(Patient p : patients) {
			if(p.getStatus2().equalsIgnoreCase(status)) {
				list.add(p);
			}
		}
		return list;
	}
	
	public static void changeAccount(Patient p, String change) throws IOException {
		change = change.toLowerCase();
		PrintStream ps = new PrintStream(p.getName());	
		switch (change) {
		case "name": 
			System.out.print("Please enter patient's name: ");
			change = input.next();
			p.setName(change); break;
		case "age":
			System.out.print("Please enter patient's age: ");
			change = input.next();
			p.setAge(Integer.parseInt(change)); break;
		case "rank":
			System.out.print("Please enter patient's severity ranking (1-10): ");
			change = input.next();
			p.setRank(Integer.parseInt(change)); break;
		case "condition":
			System.out.print("Please enter patient's condition: ");
			change = input.next();
			p.setCondition(change); break;
		case "status":
			System.out.print("Please enter patient's status: ");
			change = input.next();
			p.setStatus(change); break;
		case "room":
			System.out.print("Please enter patient's room number: ");
			change = input.next();
			p.setRoomNum(Integer.parseInt(change)); break;
		}
		createAccountFile(p);
	}
	
	public static Patient createAccount() throws IOException {

		System.out.print("Please enter patient's name: ");
		String name =input.nextLine();
		System.out.print("Please enter patient's age: "); 
		String age = input.nextLine();
		System.out.print("Please enter patient's severity ranking (1-10): "); 
		String rank =input.nextLine();
		System.out.print("Please enter patient's condition: ");
		String condition =input.nextLine();
		System.out.print("Please enter patient's status: ");
		String status =input.nextLine();
		System.out.print("Please enter patient's room number: ");
		String roomNum =input.nextLine();
		
		Patient newPatient = new Patient(name, Integer.parseInt(age), Integer.parseInt(rank), 
										 condition, status, Integer.parseInt(roomNum));
		createAccountFile(newPatient);
		return newPatient;
	}
	
	public static void createAccountFile(Patient p) throws IOException {
		PrintStream ps = new PrintStream(p.getName());
		ps.println("Name: " + p.getName());
		ps.println("Age: " + p.getAge());
		ps.println("Severity Ranking: " + p.getRank());
		ps.println("Description: " + p.getCondition());
		ps.println("Status: " + p.getStatus2());
		ps.println("Room Number: " + p.getRoomNum());
	}
}